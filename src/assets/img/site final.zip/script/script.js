//$(function()
// {
//
//var width = $(window).width();
//var fontsize=0;
//var lineheight=0;
//    var li=0;
//$(window).on('resize', function() {
//  if ($(this).width() != width) {
//    width = $(this).width();
//
//      fontsize=width*0.0439;
//      lineheight=width*0.036;
//      li=39;
//      console.log(li);
//    $('.carousel.slide .carousel-inner .item  .carousel-caption h3').css('font-size',fontsize );
//      $('.carousel.slide .carousel-inner .item  .carousel-caption').css('top',lineheight);
//
//
//  }
//});
//
//
//
//
//
//});
$(function(){
$("#aaaa").addClass("animated slideInLeft");
    var entrer = function(){

      $(".right.carousel-control").click(function(){
          $("#aaaa").addClass("animated slideInLeft");


                                        });
    }
  entrer();
  window.addEventListener('scroll', function() {
 	var element = document.querySelector('#articles-s');
  var element2 = document.querySelector('.articles2');
 	var position = element.getBoundingClientRect();
  var position2 = element2.getBoundingClientRect();

 	if(position.top < window.innerHeight) {

 		$("#article-num1").addClass("animated slideInLeft");
    $("#article-num3").addClass("animated slideInRight");
    	$("#article-num2").addClass("animated slideInDown");

 	}
  else {
    $("#article-num1").removeClass("animated slideInLeft");
    $("#article-num3").removeClass("animated slideInRight");
      $("#article-num2").removeClass("animated slideInDown");
  }
  if(position2.top < window.innerHeight) {

 		$("#article-num11").addClass("animated slideInLeft");
    $("#article-num33").addClass("animated slideInRight");
    	$("#article-num22").addClass("animated slideInDown");

 	}
  else {
    $("#article-num11").removeClass("animated slideInLeft");
    $("#article-num33").removeClass("animated slideInRight");
      $("#article-num22").removeClass("animated slideInDown");
  }
 });



});
